<?php 
/**
 * Title: Menu
 * Slug: TheDuckTaphouse&Grill/menu
 * Categories: menu
 */
?>
<!-- wp:template-part {"slug":"header","theme":"TheDuckTaphouse\u0026Grill","tagName":"header","area":"uncategorized"} /-->

<!-- wp:group {"tagName":"main","layout":{"type":"constrained"}} -->
<main class="wp-block-group"><!-- wp:group {"tagName":"section","layout":{"type":"constrained"}} -->
<section id="menu" class="wp-block-group"><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Menu</h1>
<!-- /wp:heading -->

<!-- wp:group {"tagName":"section","style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"grid","columnCount":2,"minimumColumnWidth":null}} -->
<section class="wp-block-group"><!-- wp:group {"tagName":"article","style":{"layout":{"columnSpan":1,"rowSpan":1}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<article class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<a href="/#breakfasts-section" style="display: block;">
    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/bacon.svg" alt="Breakfast Icon" class="safe-svg-inside safe-svg-inline">
</a>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p><a href="/#breakfasts-section" data-type="internal" data-id="#breakfasts-section">Breakfast</a></p>
<!-- /wp:paragraph --></article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<article class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<a href="/#appetizers-section" style="display: block;">
    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/drumstick-bite.svg" alt="Appetizers Icon" class="safe-svg-inside safe-svg-inline">
</a>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p><a href="/#appetizers-section" data-type="internal" data-id="#appetizers-section">Appetizers</a></p>
<!-- /wp:paragraph --></article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<article class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<a href="/#soup&amp;salads-section" style="display: block;">
    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/bowl-food.svg" alt="Soup & Salad Icon" class="safe-svg-inside safe-svg-inline">
</a>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p><a href="/#soup&amp;salads-section" data-type="internal" data-id="#soup&amp;salads-section">Soup &amp; Salad</a></p>
<!-- /wp:paragraph --></article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<article class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<a href="/#mains-section" style="display: block;">
    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/utensils.svg" alt="Mains Icon" class="safe-svg-inside safe-svg-inline">
</a>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p><a href="/#mains-section" data-type="internal" data-id="#mains-section">Mains</a></p>
<!-- /wp:paragraph --></article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<article class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<a href="/#handhelds-section" style="display: block;">
    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/burger.svg" alt="Handhelds Icon" class="safe-svg-inside safe-svg-inline">
</a>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p><a href="/#handhelds-section" data-type="internal" data-id="#handhelds-section">Handhelds</a></p>
<!-- /wp:paragraph --></article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<article class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<a href="/#pizza-section" style="display: block;">
    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/pizza.svg" alt="Pizza Icon" class="safe-svg-inside safe-svg-inline">
</a>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p><a href="/#pizza-section" data-type="internal" data-id="#pizza-section">10” Pizza</a></p>
<!-- /wp:paragraph --></article>
<!-- /wp:group --></section>
<!-- /wp:group --></section>
<!-- /wp:group -->

<!-- wp:media-text {"mediaPosition":"right","mediaType":"image"} -->
<div class="wp-block-media-text has-media-on-the-right is-stacked-on-mobile" id="breakfasts-section"><div class="wp-block-media-text__content"><!-- wp:heading -->
<h2 class="wp-block-heading">Breakfast</h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":6,"query":{"perPage":10,"pages":0,"offset":0,"postType":"menu-item","order":"asc","orderBy":"title","author":"","search":"","exclude":[],"sticky":"","inherit":false,"parents":[],"format":[],"taxQuery":{"menu-category":[9]}},"tagName":"section","layout":{"type":"default"}} -->
<section class="wp-block-query"><!-- wp:post-template {"style":{"spacing":{"blockGap":"0"}}} -->
<!-- wp:group {"tagName":"article","layout":{"type":"constrained"}} -->
<article class="wp-block-group"><!-- wp:group {"className":"menu-dotted-row","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group menu-dotted-row"><!-- wp:post-title {"level":3} /-->

<!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"price","fieldSettings":{"type":"number","key":"field_69aaf74ce8c5b"},"prefix":"$","displayLayout":"block","tagName":"span","className":"no-wrap"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"description","fieldSettings":{"type":"textarea","key":"field_69b834a04d243"},"hideEmpty":true,"prefix":"","displayLayout":"inline-block","tagName":"p"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"add-on_name_1","fieldSettings":{"type":"text","key":"field_69b6fff37aa66"},"hideEmpty":true,"prefix":"","suffix":": ","displayLayout":"block","tagName":"p"} /-->

<!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"add-on_price_1","fieldSettings":{"type":"number","key":"field_69b6fdaf7aa61"},"hideEmpty":true,"prefix":"$","labelAsPrefix":true,"displayLayout":"block","tagName":"span","className":"no-wrap"} /--></div>
<!-- /wp:group --></article>
<!-- /wp:group -->
<!-- /wp:post-template --></section>
<!-- /wp:query -->

<!-- wp:paragraph -->
<p><a href="/#menu" data-type="internal" data-id="#menu">&lt;-- Back to Menu</a></p>
<!-- /wp:paragraph --></div><figure class="wp-block-media-text__media"></figure></div>
<!-- /wp:media-text -->

<!-- wp:media-text {"mediaPosition":"right","mediaType":"image"} -->
<div class="wp-block-media-text has-media-on-the-right is-stacked-on-mobile" id="appetizers-section"><div class="wp-block-media-text__content"><!-- wp:heading -->
<h2 class="wp-block-heading">Appetizers</h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":6,"query":{"perPage":10,"pages":0,"offset":0,"postType":"menu-item","order":"asc","orderBy":"title","author":"","search":"","exclude":[],"sticky":"","inherit":false,"parents":[],"format":[],"taxQuery":{"menu-category":[8]}},"tagName":"section","layout":{"type":"default"}} -->
<section class="wp-block-query"><!-- wp:post-template {"style":{"spacing":{"blockGap":"0"}}} -->
<!-- wp:group {"tagName":"article","layout":{"type":"constrained"}} -->
<article class="wp-block-group"><!-- wp:group {"className":"menu-dotted-row","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group menu-dotted-row"><!-- wp:post-title {"level":3} /-->

<!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"price","fieldSettings":{"type":"number","key":"field_69aaf74ce8c5b"},"prefix":"$","labelAsPrefix":true,"displayLayout":"block","tagName":"span","className":"no-wrap"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"description","fieldSettings":{"type":"textarea","key":"field_69b834a04d243"},"hideEmpty":true,"prefix":"","displayLayout":"inline-block","tagName":"p"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"add-on_name_1","fieldSettings":{"type":"text","key":"field_69b6fff37aa66"},"hideEmpty":true,"prefix":"","displayLayout":"inline-block","tagName":"p"} /-->

<!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"add-on_price_1","fieldSettings":{"type":"number","key":"field_69b6fdaf7aa61"},"hideEmpty":true,"prefix":"$","displayLayout":"block","tagName":"span","className":"no-wrap"} /--></div>
<!-- /wp:group --></article>
<!-- /wp:group -->
<!-- /wp:post-template --></section>
<!-- /wp:query -->

<!-- wp:paragraph -->
<p><a href="/#menu" data-type="internal" data-id="#menu">&lt;-- Back to Menu</a></p>
<!-- /wp:paragraph --></div><figure class="wp-block-media-text__media"></figure></div>
<!-- /wp:media-text -->

<!-- wp:media-text {"mediaType":"image"} -->
<div class="wp-block-media-text is-stacked-on-mobile" id="soup&amp;salads-section"><figure class="wp-block-media-text__media"></figure><div class="wp-block-media-text__content"><!-- wp:heading -->
<h2 class="wp-block-heading">Soup &amp; Salads</h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":6,"query":{"perPage":10,"pages":0,"offset":0,"postType":"menu-item","order":"asc","orderBy":"title","author":"","search":"","exclude":[],"sticky":"","inherit":false,"parents":[],"format":[],"taxQuery":{"menu-category":[8]}},"tagName":"section","layout":{"type":"default"}} -->
<section class="wp-block-query"><!-- wp:post-template {"style":{"spacing":{"blockGap":"0"}}} -->
<!-- wp:group {"tagName":"article","layout":{"type":"constrained"}} -->
<article class="wp-block-group"><!-- wp:group {"className":"menu-dotted-row","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group menu-dotted-row"><!-- wp:post-title {"level":3} /-->

<!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"price","fieldSettings":{"type":"number","key":"field_69aaf74ce8c5b"},"prefix":"$","labelAsPrefix":true,"displayLayout":"block","tagName":"span","className":"no-wrap"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"description","fieldSettings":{"type":"textarea","key":"field_69b834a04d243"},"hideEmpty":true,"prefix":"","displayLayout":"inline-block","tagName":"p"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"add-on_name_1","fieldSettings":{"type":"text","key":"field_69b6fff37aa66"},"hideEmpty":true,"prefix":"","suffix":"","displayLayout":"inline-block","tagName":"p"} /-->

<!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"add-on_price_1","fieldSettings":{"type":"number","key":"field_69b6fdaf7aa61"},"hideEmpty":true,"prefix":"$","labelAsPrefix":true,"displayLayout":"block","tagName":"span","className":"no-wrap"} /--></div>
<!-- /wp:group --></article>
<!-- /wp:group -->
<!-- /wp:post-template --></section>
<!-- /wp:query -->

<!-- wp:paragraph -->
<p><a href="/#menu" data-type="internal" data-id="#menu">&lt;-- Back to Menu</a></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {"mediaType":"image"} -->
<div class="wp-block-media-text is-stacked-on-mobile" id="mains-section"><figure class="wp-block-media-text__media"></figure><div class="wp-block-media-text__content"><!-- wp:heading -->
<h2 class="wp-block-heading">Mains</h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":6,"query":{"perPage":10,"pages":0,"offset":0,"postType":"menu-item","order":"asc","orderBy":"title","author":"","search":"","exclude":[],"sticky":"","inherit":false,"parents":[],"format":[],"taxQuery":{"menu-category":[11]}},"tagName":"section","layout":{"type":"default"}} -->
<section class="wp-block-query"><!-- wp:post-template {"style":{"spacing":{"blockGap":"0"}}} -->
<!-- wp:group {"tagName":"article","layout":{"type":"constrained"}} -->
<article class="wp-block-group"><!-- wp:group {"className":"menu-dotted-row","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group menu-dotted-row"><!-- wp:post-title {"level":3} /-->

<!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"price","fieldSettings":{"type":"number","key":"field_69aaf74ce8c5b"},"prefix":"$","labelAsPrefix":true,"displayLayout":"block","tagName":"span","className":"no-wrap"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"description","fieldSettings":{"type":"textarea","key":"field_69b834a04d243"},"hideEmpty":true,"prefix":"","displayLayout":"inline-block","tagName":"p"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"add-on_name_1","fieldSettings":{"type":"text","key":"field_69b6fff37aa66"},"hideEmpty":true,"prefix":"","displayLayout":"inline-block","tagName":"p","className":"no-wrap-1"} /-->

<!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"add-on_price_1","fieldSettings":{"type":"number","key":"field_69b6fdaf7aa61"},"hideEmpty":true,"prefix":"$","labelAsPrefix":true,"displayLayout":"block","tagName":"span","className":"no-wrap"} /--></div>
<!-- /wp:group --></article>
<!-- /wp:group -->
<!-- /wp:post-template --></section>
<!-- /wp:query -->

<!-- wp:paragraph -->
<p><a href="/#menu" data-type="internal" data-id="#menu">&lt;-- Back to Menu</a></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {"mediaPosition":"right","mediaType":"image"} -->
<div class="wp-block-media-text has-media-on-the-right is-stacked-on-mobile" id="handhelds-section"><div class="wp-block-media-text__content"><!-- wp:heading -->
<h2 class="wp-block-heading">Handhelds</h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":6,"query":{"perPage":10,"pages":0,"offset":0,"postType":"menu-item","order":"asc","orderBy":"title","author":"","search":"","exclude":[],"sticky":"","inherit":false,"parents":[],"format":[],"taxQuery":{"menu-category":[10]}},"tagName":"section","layout":{"type":"default"}} -->
<section class="wp-block-query"><!-- wp:post-template {"style":{"spacing":{"blockGap":"0"}}} -->
<!-- wp:group {"tagName":"article","layout":{"type":"constrained"}} -->
<article class="wp-block-group"><!-- wp:group {"className":"menu-dotted-row","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group menu-dotted-row"><!-- wp:post-title {"level":3} /-->

<!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"price","fieldSettings":{"type":"number","key":"field_69aaf74ce8c5b"},"prefix":"$","labelAsPrefix":true,"displayLayout":"block","tagName":"span","className":"no-wrap"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"description","fieldSettings":{"type":"textarea","key":"field_69b834a04d243"},"hideEmpty":true,"prefix":"","displayLayout":"inline-block","tagName":"p"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"add-on_name_1","fieldSettings":{"type":"text","key":"field_69b6fff37aa66"},"hideEmpty":true,"prefix":"","displayLayout":"inline-block","tagName":"p"} /-->

<!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"add-on_price_1","fieldSettings":{"type":"number","key":"field_69b6fdaf7aa61"},"hideEmpty":true,"prefix":"$","labelAsPrefix":true,"displayLayout":"block","tagName":"span","className":"no-wrap"} /--></div>
<!-- /wp:group --></article>
<!-- /wp:group -->
<!-- /wp:post-template --></section>
<!-- /wp:query -->

<!-- wp:paragraph -->
<p><a href="/#menu" data-type="internal" data-id="#menu">&lt;-- Back to Menu</a></p>
<!-- /wp:paragraph --></div><figure class="wp-block-media-text__media"></figure></div>
<!-- /wp:media-text -->

<!-- wp:media-text {"mediaPosition":"right","mediaType":"image"} -->
<div class="wp-block-media-text has-media-on-the-right is-stacked-on-mobile" id="pizza-section"><div class="wp-block-media-text__content"><!-- wp:group {"tagName":"section","layout":{"type":"constrained"}} -->
<section class="wp-block-group"><!-- wp:heading -->
<h2 class="wp-block-heading">10” Pizza</h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":6,"query":{"perPage":10,"pages":0,"offset":0,"postType":"menu-item","order":"asc","orderBy":"title","author":"","search":"","exclude":[],"sticky":"","inherit":false,"parents":[],"format":[],"taxQuery":{"menu-category":[7]}},"tagName":"section","layout":{"type":"default"}} -->
<section class="wp-block-query"><!-- wp:post-template {"style":{"spacing":{"blockGap":"0"}}} -->
<!-- wp:group {"tagName":"article","layout":{"type":"constrained"}} -->
<article class="wp-block-group"><!-- wp:group {"className":"menu-dotted-row","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group menu-dotted-row"><!-- wp:post-title {"level":3} /-->

<!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"price","fieldSettings":{"type":"number","key":"field_69aaf74ce8c5b"},"prefix":"$","labelAsPrefix":true,"displayLayout":"block","tagName":"span","className":"no-wrap"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"description","fieldSettings":{"type":"textarea","key":"field_69b834a04d243"},"hideEmpty":true,"prefix":"","displayLayout":"inline-block","tagName":"p"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"className":"menu-dotted-row","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group menu-dotted-row"><!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"add-on_name_1","fieldSettings":{"type":"text","key":"field_69b6fff37aa66"},"hideEmpty":true,"prefix":"","displayLayout":"inline-block","tagName":"p"} /-->

<!-- wp:mfb/meta-field-block {"fieldType":"acf","fieldName":"add-on_price_1","fieldSettings":{"type":"number","key":"field_69b6fdaf7aa61"},"hideEmpty":true,"prefix":"$","displayLayout":"block","tagName":"span","className":"no-wrap"} /--></div>
<!-- /wp:group --></article>
<!-- /wp:group -->
<!-- /wp:post-template --></section>
<!-- /wp:query --></section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","layout":{"type":"constrained"}} -->
<section class="wp-block-group"><!-- wp:heading -->
<h2 class="wp-block-heading">Toppings:</h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":6,"query":{"perPage":100,"pages":0,"offset":0,"postType":"pizza-topping","order":"asc","orderBy":"title","author":"","search":"","exclude":[],"sticky":"","inherit":false,"parents":[],"format":[],"taxQuery":{"menu-category":[]}},"tagName":"section","layout":{"type":"constrained"}} -->
<section class="wp-block-query"><!-- wp:post-template {"className":"flex-wrap p-removed","style":{"spacing":{"blockGap":"0"}},"layout":{"type":"default","justifyContent":"center","columnCount":3}} -->
<!-- wp:group {"style":{"spacing":{"padding":{"right":"var:preset|spacing|20"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="padding-right:var(--wp--preset--spacing--20)"><!-- wp:post-title {"textAlign":"left","level":3,"className":"inline"} /-->

<!-- wp:paragraph {"style":{"layout":{"selfStretch":"fixed","flexSize":"px"}}} -->
<p>,</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- /wp:post-template --></section>
<!-- /wp:query --></section>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p><a href="/#menu" data-type="internal" data-id="#menu">&lt;-- Back to Menu</a></p>
<!-- /wp:paragraph --></div><figure class="wp-block-media-text__media"></figure></div>
<!-- /wp:media-text --></main>
<!-- /wp:group -->

<!-- wp:template-part {"slug":"footer","theme":"TheDuckTaphouse\u0026amp;Grill","area":"uncategorized"} /-->